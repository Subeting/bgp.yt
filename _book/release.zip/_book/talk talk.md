---
description: 群组交流
---

# 🤳 来唠嗑啊

我们的Telegram通知频道： [https://t.me/nijigen\_emby](https://t.me/nijigen\_emby)

频道右上三点→view discussion 即可加入群组

如有疑问或请求也可以来噢

---
description: 安卓(TV)/Windows/IOS
---

# ⏯ EMBY官方客户端

### [安卓官方](https://apkpure.com/cn/emby-for-android/com.mb.android) 📱

### [安卓TV](https://apkpure.com/cn/emby-for-android-tv/tv.emby.embyatv) 📺

### [WINDOWS APPS](https://apps.microsoft.com/store/detail/emby-theater/9NBLGGH4T70L) 🗔

### [APP STORE](https://apps.apple.com/us/app/emby/id992180193) 🍎

初次使用app可能需要选择跳过→手动连接到服务器

主机名 `https://media.nijigem.by` 端口 `443`



<figure><img src="../.gitbook/assets/image (2).png" alt=""><figcaption><p>照着输入就对了</p></figcaption></figure>


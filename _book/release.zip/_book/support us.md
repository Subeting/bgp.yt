---
description: 我很可爱，可以给我打钱吗
---

# 🙏 支持我们的发展

用爱发电是走不远的，如果可以的话，能赞助我们的发展吗？

## 邀请注册币安

[点击链接](https://www.binance.com/en/activity/referral-entry/CPA?fromActivityPage=true\&ref=CPA\_00QV12RTQP)或扫描下图二维码注册币安，我们将会收到佣金。

<div align="center">

<figure><img src=".gitbook/assets/binance.jfif" alt=""><figcaption><p>受邀注册即可返现</p></figcaption></figure>

</div>





## 给我打钱钱

![](<.gitbook/assets/image (4).png>)

USDT地址：TVp7ieYQ1VwpwDsGx6K7EZXretaQwVd8AS

ETH地址：0x8C76C0A3aacf09de65afF1C36A667F141DF6986C



## 通过我们的AFF消费

#### 👉前往[我们的AFF页面](<not fast enough.md>)

#### [戳这里看看更多AFF](http://aff.ahu.moe)

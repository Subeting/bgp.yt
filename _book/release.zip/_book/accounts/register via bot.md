---
description: '@nijigemby_helbot'
---

# 🤖 使用机器人注册

首先需要有telegram账号。

打开我们的bot注册↓

[https://t.me/nijigemby\_helbot](https://t.me/nijigemby\_helbot)

名字要求：0-9/大小写/英文下划线中任意4个字符（如：abcd/0123/AAKK/Ab3\_）



发送`/register 名字`到机器人，如`/register abcd`或`/register 1234`



错误提示：no name sensored，检测不到你的名字，即只输入了`/register`后面没有空格和你的名字

invalid, name：请按照我们的名字要求来填写名字，名字内不得含有其他字符

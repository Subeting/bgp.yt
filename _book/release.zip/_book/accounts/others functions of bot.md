# 机器人功能：其他

`/status` 查看绑定状态，如果绑定，则返回emby用户名

`/id` 查看Telegram ID

`/namecheck` 测试名字是否合法，方式和注册一样（`/namecheck 我的名字`）

暂时这么多惹

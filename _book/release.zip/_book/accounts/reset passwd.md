---
description: '@nijigemby_helbot'
---

# 🗝 重置密码

本功能暂时只开放Telegram机器人，果咩

## 机器人重置密码

[https://t.me/nijigemby\_helbot](https://t.me/nijigemby\_helbot)

需要您的Telegram账号先[绑定到emby](<bind and unbind.md>)

对机器人发送 `/reset` 即可重置密码

## 网页重置密码

待补充

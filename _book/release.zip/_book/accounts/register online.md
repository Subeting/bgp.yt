---
description: initial.nijigem.by
---

# 🌐 使用网页注册

名字：5-15个任意大小写/数字字符（例如：abcde/12345/ABCd5）

密码：5-18位的数字+字母的组合（如：ABc12/12dFa/1234a）

验证码：由于使用hcaptcha，没啥好说的。

\-----

点击食用👇

[https://initial.nijigem.by/](https://initial.nijigem.by/)

广告栏：[点击品鉴专业跨境数据加密服务](https://rd.sbs/?ct=0\&cl=0\&utm\_source=aff\&affId=36544)

---
description: 兼容性最佳
---

# ⭐ 推荐：网页版

[https://media.nijigem.by/](https://media.nijigem.by/)

↑服务器地址

没啥好说的，账号+密码

<figure><img src="../.gitbook/assets/image (7).png" alt=""><figcaption></figcaption></figure>
